/**
 * Created by Matthieu on 25/10/2016.
 * @author Matthieu
 */

/**
 * La classe TypeCheck va permettre de vérifier chaque termes d'une expression afin de les typer.
 * Le typage suis des règles strictes vu en cours. Si un terme d'une expression ne suis une de ces règles, le typage ne peut pas
 * être effectuer et par conséquent l'interpretation de l'expression entrée par l'utilisateur.
 */
public class TypeCheck {

    /**
     * Cette méthode permet de vérifier le type d'une constante. C'est la dernière étape des vérifications de typage.
     * Le resultat du calcul du terme sera effectué si la constante à le bon typage.
     * @param constante
     * @return boolean
     */
    public static boolean checkConstante(Value constante){
        // Doit toujours return true normalement
        return constante.isInteger();
    }

    public static boolean checkVariable(Variable variable){
        // TODO
    }

    /**
     * Cette méthode permet de vérifier que le type de chaque valeurs d'une addition, soustraction ou d'une multiplication soit bien un Integer.
     * Si ce n'est pas le cas, la méthode renvois false et le calcul ne sera pas effectué. Un message d'erreur sera alors indiqué
     * à l'utilisateur.
     * @param calcul
     * @return boolean
     */
    public static boolean checkOp(Calcul calcul) {
        return (calcul.getLeft().isInteger() && calcul.getRight().isInteger());
    }

    /**
     * Cette méthode permet de vérifier le type de chaque éléments d'un ifStat.
     * Si le terme n'est pas typable (qu'il ne respecte pas la règles de typage d'un ifStat) la méthode return false et le calcul n'est pas
     * effectué. C'est à ce moment que l'utilisateur verra un message d'erreur qui lui indique que son terme n'est pas typable.
     * @param ifStat
     * @return boolean
     */
    public static boolean checkIfStat(IfStat ifStat){
        if (ifStat.getLeftToEq().isInteger() && ifStat.getRightToEq().isInteger()){
            // TODO
            // Il faut vérifier que le type de thenReturn soit égal à elseReturn (cf Sujet du prof)
        } else {
            return false;
        }
    }

    /**
     * Méthode qui permet de vérifier le type d'une abstraction. Le programme va vérifier le type de la variable et le type
     * de la constante et va retourner un boolean qui détermine si l'abstraction est typable.
     * Si l'abstraction n'est pas typable, le calcul ne sera pas effectué et l'utilisateur verra un message d'erreur s'afficher
     * @param abs
     * @return boolean
     */
    public static boolean checkAbs(Abstraction abs){
        // A vérifier, pas sur pour le checkConstante
        return checkVariable(abs.getVar()) && checkConstante(abs.getExp());
    }

    /**
     * Cette méthode permet de vérifier le type d'une application.
     * A COMPLETER LORSQUE LA METHODE SERA DEFINIE.
     * @param apply
     * @return boolean
     */
    public static boolean checkApply(Apply apply){
        // TODO
    }

    /**
     * Cette méthode permet de vérifier le type d'une fonction récursive.
     * A COMPLETER LORSQUE LA METHODE SERA DEFINIE.
     * @param rec
     * @return boolean
     */
    public static boolean checkRecFuction(RecFunction rec){
        // TODO
    }


}
